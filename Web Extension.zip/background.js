browser.runtime.onInstalled.addListener(checkStoredSettingsStructure);

